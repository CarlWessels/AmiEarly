

	INSERT INTO Account(AccountName) SELECT 'Account1'
	INSERT INTO Store (StoreName, AccountGUID) SELECT 'Store1', (SELECT GUID FROM Account WHERE AccountName = 'Account1')
	INSERT INTO Customer (FirstName, Surname, AccountGUID) SELECT 'Firstname','Surname',(SELECT GUID FROM Account WHERE AccountName = 'Account1')
	INSERT INTO ServiceProvider (Firstname, Surname, AccountGUID) SELECT  'ServiceProviderName', 'ServiceProviderSurname', (SELECT GUID FROM Account WHERE AccountName = 'Account1')
	INSERT INTO ServiceProvider (Firstname, Surname, AccountGUID) SELECT  'ServiceProviderName2', 'ServiceProviderSurname2', (SELECT GUID FROM Account WHERE AccountName = 'Account1')

	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 8:00:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 9:00:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 10:00:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 12:00:00', '01:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 12:00:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 13:00:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 13:30:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 14:00:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 14:30:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 15:00:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')

	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-02 8:00:00', '00:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')

	INSERT INTO Appointment (StartDateTime, Duration, CustomerGUID, StoreGUID, ServiceProviderGUID) SELECT '2017-01-01 12:00:00', '01:30:00', (SELECT GUID FROM Customer WHERE Firstname = 'Firstname'), (SELECT GUID FROM Store WHERE Storename = 'Store1'), (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName2')

	INSERT INTO ActivityType (ActivityType, AccountGUID) SELECT 'Consultation', (SELECT GUID FROM Account WHERE AccountName = 'Account1')
	INSERT INTO ActivityType (ActivityType, AccountGUID) SELECT 'Rounds', (SELECT GUID FROM Account WHERE AccountName = 'Account1')

	INSERT INTO ActivitySchedule (DoW, Starttime, EndTime, ActivityTypeGUID, ServiceProviderGUID) SELECT 1, '8:00:00', '11:59:59', (SELECT GUID FROM ActivityType WHERE ActivityType = 'Rounds'),  (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')
	INSERT INTO ActivitySchedule (DoW, Starttime, EndTime, ActivityTypeGUID, ServiceProviderGUID) SELECT 1, '12:00:00', '17:00:00', (SELECT GUID FROM ActivityType WHERE ActivityType = 'Consultation'),  (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName')

	INSERT INTO ActivitySchedule (DoW, Starttime, EndTime, ActivityTypeGUID, ServiceProviderGUID) SELECT 2, '8:00:00', '17:00:00', (SELECT GUID FROM ActivityType WHERE ActivityType = 'Consultation'),  (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName2')
	INSERT INTO ActivitySchedule (DoW, Starttime, EndTime, ActivityTypeGUID, ServiceProviderGUID) SELECT 3, '8:00:00', '17:00:00', (SELECT GUID FROM ActivityType WHERE ActivityType = 'Consultation'),  (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName2')
	INSERT INTO ActivitySchedule (DoW, Starttime, EndTime, ActivityTypeGUID, ServiceProviderGUID) SELECT 4, '8:00:00', '17:00:00', (SELECT GUID FROM ActivityType WHERE ActivityType = 'Consultation'),  (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName2')
	INSERT INTO ActivitySchedule (DoW, Starttime, EndTime, ActivityTypeGUID, ServiceProviderGUID) SELECT 5, '8:00:00', '17:00:00', (SELECT GUID FROM ActivityType WHERE ActivityType = 'Consultation'),  (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName2')
	INSERT INTO ActivitySchedule (DoW, Starttime, EndTime, ActivityTypeGUID, ServiceProviderGUID) SELECT 6, '8:00:00', '17:00:00', (SELECT GUID FROM ActivityType WHERE ActivityType = 'Consultation'),  (SELECT GUID FROM ServiceProvider WHERE Firstname = 'ServiceProviderName2')
